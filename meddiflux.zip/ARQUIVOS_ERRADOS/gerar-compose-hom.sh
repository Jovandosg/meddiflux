cp -f docker-compose-hom.yml docker-compose.yml

echo "docker-compose.yml gerado com sucesso para o ambiente Hom!"
