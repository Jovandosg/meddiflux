cp -f docker-compose-prod.yml docker-compose.yml

echo "docker-compose.yml gerado com sucesso para o ambiente Prod!"
